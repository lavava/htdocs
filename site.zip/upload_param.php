<?php
  // Define application constants
  define('GW_UPLOADPATH', 'uploads/');
  define('GW_MAXFILESIZE', 524288);      // 512 KB
?>
